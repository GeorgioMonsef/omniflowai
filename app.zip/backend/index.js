const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Database file path
const dbPath = path.resolve(__dirname, 'database.sqlite');

// Initialize SQLite database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        `, (err) => {
            if (err) {
                console.error('Error creating table:', err);
            } else {
                console.log('Users table ready');
            }
        });
    }
});

// API to add a user (for testing)
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const query = `INSERT INTO users (username, password) VALUES (?, ?)`;
    db.run(query, [username, password], (err) => {
        if (err) {
            res.status(500).json({ error: 'Username already exists' });
        } else {
            res.json({ message: 'User registered successfully' });
        }
    });
});

// API to fetch all users (for testing)
app.get('/users', (req, res) => {
    const query = `SELECT id, username FROM users`;
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: 'Error fetching users' });
        } else {
            res.json(rows);
        }
    });
});

// Start the server
const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Backend server running at http://localhost:${PORT}`);
});
